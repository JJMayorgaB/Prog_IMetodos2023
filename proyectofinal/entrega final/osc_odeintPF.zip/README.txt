Proyecto: Disipación de Energía en Osciladores Acoplados

Para mas información del proyecto se puede revisar el siguiente video: https://youtu.be/kksOEASyW_U

Este proyecto se centra en la simulación y estudio de la disipación de energía en un sistema de osciladores acoplados. El objetivo principal es analizar el tiempo de disipación de energía en un conjunto de osciladores acoplados y cómo afecta a la evolución del sistema a lo largo que se aumenta su complejidad.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Contiene los siguientes archivos:

-osc_acop.h y osc_acop.cpp: Estos archivos contienen las definiciones y las implementaciones de las funciones relacionadas con el sistema de osciladores acoplados, como el cálculo de las derivadas, la integración numérica y la energía total.

-main_cond_aleatorias.cpp: Este archivo implementa el programa principal que realiza la integración del sistema de osciladores acoplados utilizando condiciones iniciales aleatorias.

-main_cond_inversas.cpp: Este archivo implementa el programa principal que realiza la integración del sistema de osciladores acoplados utilizando condiciones iniciales inversas.

-main_cond_uniformes.cpp: Este archivo implementa el programa principal que realiza la integración del sistema de osciladores acoplados utilizando condiciones iniciales uniformes.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Requisitos del Sistema:

Se requiere tener instalado un compilador de C++ compatible, como GCC o Clang.

Se recomienda tener instalada la biblioteca Boost (https://www.boost.org) para aprovechar las capacidades adicionales de la biblioteca Boost.ODEIntegrators utilizada en el proyecto.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Para ejecutar el programa:

Compila los archivos fuente utilizando el compilador de C++. Por ejemplo, utilizando GCC:
g++ -std=c++14 -I"ruta a la carpeta que contiene boost" -L"ruta a la carpeta que contiene odeint" main_cond_aleatorias.cpp osc_acop.cpp

Ejecuta el programa deseado para simular el sistema de osciladores acoplados con las condiciones iniciales correspondientes:
./a

Observa los resultados de la simulación en la salida estándar o en los archivos de salida generados por el programa, como "time.txt" en el caso de los programas de condiciones aleatorias, inversas y uniformes.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Este proyecto fue realizado por:

-Aunta Molina, Luis Diego
-Cruz Cuellar, Carlos Andres
-Mayorga Bonilla, Juan José
-Paez Borda, Sebastian